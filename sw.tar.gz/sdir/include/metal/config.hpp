#ifndef METAL_CONFIG_HPP
#define METAL_CONFIG_HPP

#include "config/config.hpp"
#include "config/version.hpp"

/// \defgroup config Config
/// \ingroup metal

#endif
