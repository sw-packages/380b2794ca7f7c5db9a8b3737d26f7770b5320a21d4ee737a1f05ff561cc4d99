#define METAL_WORKAROUND
#include <metal.hpp>

int main() {
    return 0;
}
