#include <metal.hpp>

#include "test.hpp"

#define MATRIX(M, N) \
    CHECK((metal::is_invocable<metal::lambda<metal::list> COMMA(N) VALUES(N)>), (TRUE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::list> COMMA(N) NUMBERS(N)>), (TRUE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::list> COMMA(N) PAIRS(N)>), (TRUE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::list> COMMA(N) LISTS(N)>), (TRUE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::list> COMMA(N) MAPS(N)>), (TRUE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::list> COMMA(N) LAMBDAS(N)>), (TRUE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::as_list>, VALUE(M)>), (FALSE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::as_list>, NUMBER(M)>), (FALSE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::as_list>, PAIR(M)>), (TRUE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::as_list>, LIST(M)>), (TRUE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::as_list>, MAP(M)>), (TRUE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::as_list>, LAMBDA(M)>), (FALSE)); \
    CHECK((metal::is_invocable<metal::lambda<metal::as_list>, LAMBDA(_)>), (FALSE)); \
    CHECK((metal::is_list<VALUE(N)>), (FALSE)); \
    CHECK((metal::is_list<NUMBER(N)>), (FALSE)); \
    CHECK((metal::is_list<PAIR(N)>), (TRUE)); \
    CHECK((metal::is_list<LIST(N)>), (TRUE)); \
    CHECK((metal::is_list<MAP(N)>), (TRUE)); \
    CHECK((metal::is_list<LAMBDA(N)>), (FALSE)); \
    CHECK((metal::is_list<LAMBDA(_)>), (FALSE)); \
    CHECK((metal::as_list<PAIR(N)>), (PAIR(N))); \
    CHECK((metal::as_list<LIST(N)>), (LIST(N))); \
    CHECK((metal::as_list<MAP(N)>), (MAP(N))); \
/**/

GEN(MATRIX)

